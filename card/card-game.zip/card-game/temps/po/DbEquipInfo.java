package com.fatiny.game.po;

import com.fatiny.game.po.TbDbEquipInfoPo;
import com.good.data.*;

/**
 * this class file is auto output by net.good321.frame.db.tool.POPrinter
 * @author chao
 * @see net.good321.frame.db.tool.PoPrinter
 */
@PO("db_equip_info")
public class DbEquipInfo extends TbDbEquipInfoPo {

	public DbEquipInfo() {

	}

	@Override
	public long key() {
		//TODO 第一主键的数据值, 例如playerId
		return 
	}

	@Override
	public String cacheId() {
		//TODO 缓存的二级ID, 如果不是一对多关系的return null即可
		return 
	}

	@Override
	public String keyColumn() {
		//TODO 第一主键的数据库列名
		return 
	}

}
